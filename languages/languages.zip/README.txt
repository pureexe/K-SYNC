If you want to translate KONAYUKI PLUS to your language, please translate the .json file and submit to us via the following link down below.
- Facebook	: https://fb.com/Konayuki.moe
- Twitter	: https://twitter.com/Konayuki_moe
- Discord	: https://link.konayuki.moe/discord.html